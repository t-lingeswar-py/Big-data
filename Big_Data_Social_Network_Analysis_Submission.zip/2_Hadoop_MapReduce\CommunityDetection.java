import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class CommunityDetection {

    public static class LPAMapper extends Mapper<LongWritable, Text, Text, Text> {
        private Text nodeKey = new Text();
        private Text voteVal = new Text();

        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString().trim();
            if (line.isEmpty() || line.startsWith("#")) return;

            String[] parts = line.split("\t");
            if (parts.length >= 2) {
                String src = parts[0];
                String dst = parts[1];

                nodeKey.set(dst);
                voteVal.set(src);
                context.write(nodeKey, voteVal);

                nodeKey.set(src);
                voteVal.set(dst);
                context.write(nodeKey, voteVal);
            }
        }
    }

    public static class LPAReducer extends Reducer<Text, Text, Text, Text> {
        private Text result = new Text();

        public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            Map<String, Integer> counts = new HashMap<>();

            for (Text val : values) {
                String label = val.toString();
                counts.put(label, counts.getOrDefault(label, 0) + 1);
            }

            String majorityLabel = "";
            int maxCount = -1;
            for (Map.Entry<String, Integer> entry : counts.entrySet()) {
                if (entry.getValue() > maxCount) {
                    maxCount = entry.getValue();
                    majorityLabel = entry.getKey();
                }
            }

            result.set(majorityLabel + "\t" + maxCount);
            context.write(key, result);
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.err.println("Usage: CommunityDetection <input_path> <output_path>");
            System.exit(1);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Community Detection");
        job.setJarByClass(CommunityDetection.class);

        job.setMapperClass(LPAMapper.class);
        job.setReducerClass(LPAReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
