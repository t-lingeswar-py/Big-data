import org.apache.spark.sql.SparkSession
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD
import java.io.File
import scala.io.StdIn

object SocialNetworkAnalysis {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("GraphX_SocialNetworkAnalysis")
      .master("local[*]")
      .config("spark.driver.host", "localhost")
      .config("spark.driver.memory", "4g")
      .config("spark.ui.enabled", "true")
      .config("spark.ui.port", "4040")
      .getOrCreate()
      
    val sc = spark.sparkContext
    sc.setLogLevel("WARN")

    val datasetPath = if (args.length > 0) {
      args(0)
    } else if (new File("pokec_3M.txt").exists()) {
      "pokec_3M.txt"
    } else if (new File("../1_Dataset/pokec_3M.txt").exists()) {
      "../1_Dataset/pokec_3M.txt"
    } else if (new File("soc-pokec-relationships.txt").exists()) {
      "soc-pokec-relationships.txt"
    } else {
      "/user/data/pokec_3M.txt"
    }
    
    println(s"Loading dataset: $datasetPath")
    val startTime = System.currentTimeMillis()

    val edgesRDD: RDD[Edge[Int]] = sc.textFile(datasetPath)
      .filter(line => !line.trim.isEmpty && !line.startsWith("#"))
      .map { line =>
        val parts = line.split('\t')
        Edge(parts(0).toLong, parts(1).toLong, 1)
      }

    val graph = Graph.fromEdges(edgesRDD, defaultValue = 1)
    graph.cache()

    val numVertices = graph.vertices.count()
    val numEdges = graph.edges.count()
    val constructDuration = (System.currentTimeMillis() - startTime) / 1000.0

    println(s"Total Users: $numVertices")
    println(s"Total Edges: $numEdges")
    println(s"Graph Construction Time: $constructDuration s")

    println("\nRunning Community Detection (LPA)...")
    val lpaStart = System.currentTimeMillis()

    val maxIterations = 5
    val lpaGraph = lib.LabelPropagation.run(graph, maxIterations)
    lpaGraph.vertices.cache()

    val lpaDuration = (System.currentTimeMillis() - lpaStart) / 1000.0
    println(s"Community Detection Time: $lpaDuration s")

    println("Sample Communities (User -> Community):")
    lpaGraph.vertices.take(10).foreach { case (userId, communityId) =>
      println(s"User $userId -> Community $communityId")
    }

    println("\nRunning Link Prediction...")
    val lpStart = System.currentTimeMillis()

    val undirectedEdges = graph.edges.flatMap(e => Seq((e.srcId, e.dstId), (e.dstId, e.srcId))).distinct()
    val sharedNeighbors = undirectedEdges.groupByKey()

    val potentialLinks = sharedNeighbors.flatMap { case (sharedNode, neighbors) =>
      val neighborsList = neighbors.take(30).toList
      for {
        a <- neighborsList
        c <- neighborsList
        if a < c
      } yield ((a, c), 1)
    }

    val linkPredictionScores = potentialLinks.reduceByKey(_ + _)
      .sortBy(_._2, ascending = false)

    val lpDuration = (System.currentTimeMillis() - lpStart) / 1000.0
    println(s"Link Prediction Time: $lpDuration s")

    println("Top 10 Predicted Links:")
    linkPredictionScores.take(10).foreach { case ((u1, u2), score) =>
      println(s"Pair: $u1 <---> $u2 | Mutual Friends: $score")
    }

    val totalDuration = (System.currentTimeMillis() - startTime) / 1000.0
    println(s"Total Execution Time: $totalDuration s")

    println("\nSpark Web UI is live at: http://localhost:4040")
    println("Press Enter to stop Spark...")
    try {
      StdIn.readLine()
    } catch {
      case _: Exception =>
    }

    spark.stop()
  }
}
