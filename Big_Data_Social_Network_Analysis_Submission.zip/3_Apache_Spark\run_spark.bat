@echo off
if exist ..\..\apache-maven-3.9.6\bin\mvn.cmd (
    ..\..\apache-maven-3.9.6\bin\mvn.cmd exec:exec
) else if exist ..\apache-maven-3.9.6\bin\mvn.cmd (
    ..\apache-maven-3.9.6\bin\mvn.cmd exec:exec
) else (
    mvn exec:exec
)
pause
