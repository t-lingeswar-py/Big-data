import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import scala.Tuple2;

import java.io.File;
import java.io.Serializable;
import java.util.*;

public class SocialNetworkAnalysisSpark implements Serializable {

    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .appName("SocialNetworkAnalysisSpark")
                .master("local[*]")
                .config("spark.driver.host", "localhost")
                .config("spark.driver.memory", "4g")
                .config("spark.ui.enabled", "true")
                .config("spark.ui.port", "4040")
                .getOrCreate();

        JavaSparkContext sc = new JavaSparkContext(spark.sparkContext());
        sc.setLogLevel("WARN");

        String datasetPath = "pokec_3M.txt";
        if (!new File(datasetPath).exists()) {
            datasetPath = "../1_Dataset/pokec_3M.txt";
        }
        if (!new File(datasetPath).exists()) {
            datasetPath = "soc-pokec-relationships.txt";
        }
        System.out.println("Loading dataset: " + datasetPath);

        long startTime = System.currentTimeMillis();

        JavaRDD<String> lines = sc.textFile(datasetPath);
        JavaPairRDD<Long, Long> edges = lines
                .filter(line -> !line.trim().isEmpty() && !line.startsWith("#"))
                .mapToPair(line -> {
                    String[] parts = line.split("\t");
                    return new Tuple2<>(Long.parseLong(parts[0]), Long.parseLong(parts[1]));
                })
                .distinct();

        edges.cache();

        long numEdges = edges.count();
        JavaRDD<Long> vertices = edges.flatMap(e -> Arrays.asList(e._1(), e._2()).iterator()).distinct();
        vertices.cache();
        long numVertices = vertices.count();

        System.out.println("Total Users: " + numVertices);
        System.out.println("Total Edges: " + numEdges);
        System.out.println("Graph Construction Time: " + (System.currentTimeMillis() - startTime) / 1000.0 + " s");

        System.out.println("\nRunning Community Detection (LPA)...");
        long lpaStart = System.currentTimeMillis();

        JavaPairRDD<Long, Long> votes = edges.flatMapToPair(edge -> {
            long u = edge._1();
            long v = edge._2();
            return Arrays.asList(
                    new Tuple2<>(v, u),
                    new Tuple2<>(u, v)
            ).iterator();
        });

        JavaPairRDD<Long, Tuple2<Long, Integer>> communityAssignments = votes.groupByKey().mapValues(incomingLabels -> {
            Map<Long, Integer> counts = new HashMap<>();
            for (Long label : incomingLabels) {
                counts.put(label, counts.getOrDefault(label, 0) + 1);
            }
            long majorityLabel = -1;
            int maxCount = -1;
            for (Map.Entry<Long, Integer> entry : counts.entrySet()) {
                if (entry.getValue() > maxCount) {
                    maxCount = entry.getValue();
                    majorityLabel = entry.getKey();
                }
            }
            return new Tuple2<>(majorityLabel, maxCount);
        });

        communityAssignments.cache();

        System.out.println("Sample Communities (User -> Community | Votes):");
        List<Tuple2<Long, Tuple2<Long, Integer>>> sampleCommunities = communityAssignments.take(10);
        for (Tuple2<Long, Tuple2<Long, Integer>> sample : sampleCommunities) {
            System.out.println("User " + sample._1() + " -> Community " + sample._2()._1() + " (Votes: " + sample._2()._2() + ")");
        }
        System.out.println("Community Detection Time: " + (System.currentTimeMillis() - lpaStart) / 1000.0 + " s");

        System.out.println("\nRunning Link Prediction...");
        long lpStart = System.currentTimeMillis();

        JavaPairRDD<Long, Long> reverseEdges = edges.mapToPair(Tuple2::swap).distinct();
        JavaPairRDD<Long, Iterable<Long>> sharedNeighbors = reverseEdges.groupByKey();

        JavaPairRDD<String, Integer> candidatePairs = sharedNeighbors.flatMapToPair(entry -> {
            List<Tuple2<String, Integer>> pairs = new ArrayList<>();
            List<Long> followers = new ArrayList<>();
            int count = 0;
            for (Long f : entry._2()) {
                followers.add(f);
                if (++count >= 30) break;
            }
            for (int i = 0; i < followers.size(); i++) {
                for (int j = i + 1; j < followers.size(); j++) {
                    long u1 = followers.get(i);
                    long u2 = followers.get(j);
                    if (u1 > u2) {
                        long tmp = u1; u1 = u2; u2 = tmp;
                    }
                    pairs.add(new Tuple2<>(u1 + " <---> " + u2, 1));
                }
            }
            return pairs.iterator();
        });

        JavaPairRDD<String, Integer> linkScores = candidatePairs.reduceByKey(Integer::sum);

        List<Tuple2<Integer, String>> topLinks = linkScores
                .mapToPair(Tuple2::swap)
                .sortByKey(false)
                .take(10);

        System.out.println("Top 10 Predicted Links:");
        for (Tuple2<Integer, String> link : topLinks) {
            System.out.println("Pair: " + link._2() + " | Mutual Friends: " + link._1());
        }
        System.out.println("Link Prediction Time: " + (System.currentTimeMillis() - lpStart) / 1000.0 + " s");
        System.out.println("Total Execution Time: " + (System.currentTimeMillis() - startTime) / 1000.0 + " s");

        System.out.println("\nSpark Web UI is live at: http://localhost:4040");
        System.out.println("Press Enter to stop Spark...");
        new Scanner(System.in).nextLine();

        spark.stop();
    }
}
